$(document).ready(function(){

//CONNECTION CHECK
		// $("button").click(function() {
		// (alert) ("you clicked");
		// });

		$("img").click(function() {
		$(this).hide();
		});


		$("button").click(function() {
		$(this).show();
		});
});